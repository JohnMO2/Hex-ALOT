using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;

//public class HexALOT_DataStructures
public class HexALOT_DataStructures : MonoBehaviour // If using unity use this
{
    public class Leg // Unused code.
    {
        public Joint Hip;
        public Joint Femur;
        public Joint Tibia;
        public Joint StaticReferencePoint;
        
    }
    // Joints are 2 points seperated by a distance. Joints dont really do much other then help keep the code tidy.
    public class Joint
    {
        public Point Start { get; private set; }
        public Point End { get; private set; }
        public Joint Parent { get; private set; }
        public List<Joint> Children { get; private set; } 
        public Joint(Point start = null, Point end = null, Joint parent = null) // The points are in local space.
        {
            Start = start == null ? new Point() : start;
            End = end == null ? new Point() : end;
            Children = new List<Joint>();
            
            SetParent(parent);
            End.SetParent(Start);
        }
        public void AddChild(Joint Child)
        {
            Children.Add(Child);
        }
        public void RemoveChild(Joint Child)
        {
            Children.Remove(Child);
        }
        public void SetParent(Joint NewParent)
        {
            Parent?.RemoveChild(this);
            Parent = NewParent;
            Parent?.AddChild(this);
            //While joints can have parents, to make the logic actually work we have to link together the points in this joint with the parent joint points.
            if (Parent != null)
            {
                Start.SetParent(Parent.End);
            }
            //Debug.Log("Set Parent to: " + Parent?.ToString());
        }

        public void Rotate(System.Numerics.Vector3 Angles)
        {
            
            Start.RotateLocaly(Angles);
            //Debug.Log("Before Joint " + ": Pos = " + Start.GlobalPos + ", Rot = " + (Angles * Mathf.Rad2Deg).ToString());
        }

    }
    public class Limit
    {
        public bool UseLimit = false; // By default joints do not use limits.
        public System.Numerics.Vector3 Max; // Maximun Value
        public System.Numerics.Vector3 Min; // Minimun Value
        public Limit(System.Numerics.Vector3 max = new System.Numerics.Vector3(), System.Numerics.Vector3 min = new System.Numerics.Vector3())
        {
            Max = max;
            Min = min;
        }
        public System.Numerics.Vector3 ApplyLimits(System.Numerics.Vector3 V)
        {
            if (!UseLimit)
            {
                return V;
            }
            System.Numerics.Vector3 LimitedV = new System.Numerics.Vector3();
            LimitedV.X = Math.Max(Min.X, Math.Min(Max.X, Wrap(V.X)));
            LimitedV.Y = Math.Max(Min.Y, Math.Min(Max.Y, Wrap(V.Y)));
            LimitedV.Z = Math.Max(Min.Z, Math.Min(Max.Z, Wrap(V.Z)));
            return LimitedV;
        }
        private float Wrap(float Angle)
        {
            return Angle;
            return (((Angle * 180 / (float)Math.PI) + 180) % 360 - 180) * (float)Math.PI / 180;
        }
    }
    // A point is the backbone of this system. Every point can have a parent and multiple children as well as a local offset.
    public class Point
    {
        public System.Numerics.Vector3 GlobalPos { get; private set; }
        public System.Numerics.Vector3 LocalPos { get; private set; }
        public System.Numerics.Quaternion GlobalRot { get; private set; }
        public System.Numerics.Vector3 LocalRot { get; private set; }
        public Point Parent { get; private set; }
        public List<Point> Children { get; private set; }
        public Limit LocalRotationLimit;
        public Point(System.Numerics.Vector3 Pos = new System.Numerics.Vector3(), Point parent = null )
        {
            Children = new List<Point>();
            SetParent(parent);
            SetGlobalPos(Pos);
            GlobalRot = new System.Numerics.Quaternion();
            LocalRot = new System.Numerics.Vector3(0, 0, 0);
            LocalRotationLimit = new Limit();
        }
        public void AddChild(Point Child)
        {
            Children.Add(Child);
        }
        public void RemoveChild(Point Child)
        {
            Children.Remove(Child);
        }
        public void SetParent(Point NewParent) // If NewParent == Null then it will just clear the existing parent.
        {
            Parent?.RemoveChild(this);
            Parent = NewParent;
            Parent?.AddChild(this);
        }
        public void SetLocalPos(System.Numerics.Vector3 Target)
        {
            LocalPos = Target;
            Update();
        }
        public void SetGlobalPos(System.Numerics.Vector3 Target) // Instead of handling global pos, I convert to local pos and update it.
        {
            LocalPos =  Parent == null ? Target : (Target - Parent.GlobalPos);
            Update();
        }
        private void UpdateGlobalPos()
        {
            GlobalPos = (Parent == null ? LocalPos : Parent.GlobalPos + System.Numerics.Vector3.Transform(LocalPos,Parent.GlobalRot));
        }

        private void UpdateChildren()
        {
            for (int i = 0; i < Children.Count; i++)
            {
                Children[i].Update();
            }
        }
        public void SetLocalRot(System.Numerics.Vector3 Target)
        {
            LocalRot = Target;
            Update();
        }
        public void RotateLocaly(System.Numerics.Vector3 Target)
        {
            
            LocalRot += Target; // Due to it being a local rotation I dont have to mess around with quaternions.
            SetLocalRot(LocalRotationLimit.ApplyLimits(LocalRot)); // This applies the rotation limits.
        }
        public void SetGlobalRot(System.Numerics.Quaternion Target) // Instead of handling global rotation, I convert to local rotation and update it.
        {
            LocalRot = EulerAngles.FromQuaternion( Parent?.GlobalRot == null ? Target : (System.Numerics.Quaternion.Inverse(Parent.GlobalRot) * EulerAngles.ToQuaternion(LocalRot)));
            Update();
        }
        public void Update()
        {
            //Debug.Log("Global Rotation is: " + GlobalRot.ToString());
            UpdateGlobalRot();
            UpdateGlobalPos();
            UpdateChildren();
        }
        private void UpdateGlobalRot() // Rotates this points rotation around the parents global rotation. This uses local rotation as its the only method that updates the global rotation.
        {
            GlobalRot = Parent?.GlobalRot == null ? EulerAngles.ToQuaternion(LocalRot) : (Parent.GlobalRot * EulerAngles.ToQuaternion(LocalRot));
            //Debug.Log("Global Rotation set to: " + GlobalRot.ToString());
        }

    }
    public struct EulerAngles
    {
        public static System.Numerics.Vector3 FromQuaternion(System.Numerics.Quaternion q)
        {
            //Version to use when testing using unitys methods.
            /*
            System.Numerics.Vector3 angles = new System.Numerics.Vector3();
            UnityEngine.Quaternion Q2 = new UnityEngine.Quaternion(q.X, q.Y, q.Z, q.W);
            UnityEngine.Vector3 V2 = Q2.eulerAngles;
            return Vec3UnityToSystem(V2);
            */
            return QuaternionToEuler(q);
            
        }
        //This was my method of handling quaternions but it did not work well.
        /*
        public static System.Numerics.Vector3 FromQuaternion(System.Numerics.Quaternion q)
        {
            System.Numerics.Vector3 angles = new System.Numerics.Vector3();

            // roll / x
            float sinr_cosp = 2 * (q.W * q.X + q.Y * q.Z);
            float cosr_cosp = 1 - 2 * (q.X * q.X + q.Y * q.Y);
            angles.X = (float)Math.Atan2(sinr_cosp, cosr_cosp);

            // pitch / y
            float sinp = 2 * (q.W * q.Y - q.Z * q.X);
            angles.Y = Math.Abs(sinp) >= 1 ? angles.Y = Math.Abs((float)Math.PI / 2) * Math.Sign(sinp) : angles.Y = (float)Math.Asin(sinp);
            // yaw / z
            float siny_cosp = 2 * (q.W * q.Z + q.X * q.Y);
            float cosy_cosp = 1 - 2 * (q.Y * q.Y + q.Z * q.Z);
            angles.Z = (float)Math.Atan2(siny_cosp, cosy_cosp);

            return angles;
        }
        */
        //So I stole this code
        public static System.Numerics.Vector3 QuaternionToEuler(System.Numerics.Quaternion q)
        {
            System.Numerics.Vector3 euler;

            // if the input quaternion is normaliZed, this is eXactlY one. Otherwise, this acts as a correction factor for the quaternion's not-normaliZedness
            float unit = (q.X * q.X) + (q.Y * q.Y) + (q.Z * q.Z) + (q.W * q.W);

            // this will have a magnitude of 0.5 or greater if and onlY if this is a singularitY case
            float test = q.X * q.W - q.Y * q.Z;

            if (test > 0.4995f * unit) // singularitY at north pole
            {
                euler.X = (float)Math.PI / 2;
                euler.Y = 2f * (float)Math.Atan2(q.Y, q.X);
                euler.Z = 0;
                //Debug.Log("A");
            }
            else if (test < -0.4995f * unit) // singularitY at south pole
            {
                euler.X = -(float)Math.PI / 2;
                euler.Y = -2f * (float)Math.Atan2(q.Y, q.X);
                euler.Z = 0;
                //Debug.Log("B");
            }
            else // no singularitY - this is the majoritY of cases
            {
                euler.X = (float)Math.Asin(2f * (q.W * q.X - q.Y * q.Z));
                euler.Y = (float)Math.Atan2(2f * q.W * q.Y + 2f * q.Z * q.X, 1 - 2f * (q.X * q.X + q.Y * q.Y));
                euler.Z = (float)Math.Atan2(2f * q.W * q.Z + 2f * q.X * q.Y, 1 - 2f * (q.Z * q.Z + q.X * q.X));
                //Debug.Log("C");
            }

            // all the math so far has been done in radians. Before returning, we convert to degrees...
            //euler *= Mathf.Rad2Deg;

            //...and then ensure the degree values are between 0 and 360
            euler.X %= 360 * (float)Math.PI / 180;
            euler.Y %= 360 * (float)Math.PI / 180;
            euler.Z %= 360 * (float)Math.PI / 180;

            return euler;
        }
        public static System.Numerics.Quaternion ToQuaternion(System.Numerics.Vector3 V)
        {
            //return QuaternionUnityToSystem(UnityEngine.Quaternion.Euler(Vec3SystemToUnity(V * Mathf.Rad2Deg))); // Unity Version
            return System.Numerics.Quaternion.CreateFromYawPitchRoll(V.Y, V.X, V.Z);
        }
    }
    public static class VectorHelper
    {
        public static System.Numerics.Vector3 GetAngleBetween(System.Numerics.Vector3 A, System.Numerics.Vector3 B) //Get the euler angles between 2 Vector3s
        {
            //Debug.Log("A is: " + A.ToString() + " And B is: " + B.ToString());
            System.Numerics.Vector3 Axis = System.Numerics.Vector3.Normalize(System.Numerics.Vector3.Cross(A, B));
            float Angle = (float)Math.Acos(System.Numerics.Vector3.Dot(A , B) / A.Length() / B.Length());
            Angle = float.IsNaN(Angle) ? 0 : Angle;
            //Debug.Log("Angle is: " + Angle + " And Axis is: " + Axis.ToString());
            return AxisAngleToEuler(Axis, Angle);
        }
        public static System.Numerics.Vector3 AxisAngleToEuler(System.Numerics.Vector3 Axis, float Angle)
        {
            return EulerAngles.FromQuaternion(System.Numerics.Quaternion.CreateFromAxisAngle(Axis, Angle)); // Converts to quaternion, then to euler because I am too lazy to code axis angle to euler
            //return EulerAngles.FromQuaternion(QuaternionUnityToSystem(UnityEngine.Quaternion.AngleAxis(Angle, Vec3SystemToUnity(Axis)))); // Unity Version
        }
    }
    // The following is used for testing with unity.
    /*
    private static System.Numerics.Quaternion QuaternionUnityToSystem(UnityEngine.Quaternion Q)
    {
        return new System.Numerics.Quaternion(Q.x, Q.y, Q.z, Q.w);
    }
    private static UnityEngine.Quaternion QuaternionSystemToUnity(System.Numerics.Quaternion Q)
    {
        return new UnityEngine.Quaternion(Q.X, Q.Y, Q.Z, Q.W);
    }
    private static System.Numerics.Vector3 Vec3UnityToSystem( UnityEngine.Vector3 Vect)
    {
        return new System.Numerics.Vector3(Vect.x, Vect.y, Vect.z);
    }
    private static UnityEngine.Vector3 Vec3SystemToUnity(System.Numerics.Vector3 Vect)
    {
        return new UnityEngine.Vector3(Vect.X, Vect.Y, Vect.Z);
    }
    */
}
