using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System;
using UnityEngine;

//public class JMO_KinematicsSolver
public class JMO_KinematicsSolver : MonoBehaviour // If using unity use this
{
    HexALOT_DataStructures HADS;
    public List<HexALOT_DataStructures.Joint> JointList = null;
    private void Start()
    {
        TestGetAngleBetween();
    }
    public bool BuildList(HexALOT_DataStructures.Joint Root, HexALOT_DataStructures.Joint End) // This moves upwards the tree of joints to build a list of the joints between the start and end.
    {
        JointList = new List<HexALOT_DataStructures.Joint>();
        int i = 0;
        JointList.Add(End);
        //This list starts at the end, so before we break out of the loop we need to reverse it.
        while (true) // Scary while true statement 
        {
            if (JointList[i].Parent == null)
            {
                JointList.Reverse();
                return false;
            }
            if (JointList[i] == Root)
            {
                JointList.Reverse();
                return true;
                
            }
            JointList.Add(JointList[i].Parent);


            i++;
        }
    }
    public void Solve(HexALOT_DataStructures.Point Target, int Count = 50)
    {
        Solve(JointList, Target, Count);
    }
    // All this does is take the vector fromed by the leg starting at a joint I to the end joint. 
    // It then goes to the next joint down the list rotating each to get close to the target position.
    // It will then repeat this c times, I use 50 as a default but it seems to work well with a c as low as 5.
    public void Solve(List<HexALOT_DataStructures.Joint> Joints, HexALOT_DataStructures.Point Target, int Count = 50) { 
        int Last = Joints.Count - 1;
        //Debug.Log("Last is: " + Last);
        //Debug.Log("Last is: " + Joints[Last].End.GlobalPos.ToString());
        for (int c = 0; c < Count; c++)
        {
            for (int i = 0; i < Joints.Count; i++)
            {
                System.Numerics.Vector3 TargetVect = Target.GlobalPos - Joints[i].Start.GlobalPos;
                //TargetVect.X = Math.Sign(TargetVect.X) == -1 ? -TargetVect.X : TargetVect.X;
                Joints[i].Rotate(HexALOT_DataStructures.VectorHelper.GetAngleBetween(Joints[Last].End.GlobalPos - Joints[i].Start.GlobalPos, TargetVect));
                //Debug.Log("After Joint " + i + ": Pos = " + Joints[i].Start.GlobalPos + ", Rot = " + (Joints[i].Start.LocalRot * Mathf.Rad2Deg).ToString());
                //Debug.Log(HexALOT_DataStructures.VectorHelper.GetAngleBetween(Joints[Last].End.GlobalPos - Joints[i].Start.GlobalPos, Target.GlobalPos - Joints[i].Start.GlobalPos).ToString());
            }
        }
        float tests;
        
    }
    //The following code is a WIP and is untested.
    public void TestGetAngleBetween() // This is just to test the get angle between method.
    {
        System.Numerics.Vector3 testVector1 = new System.Numerics.Vector3(-3.0f, 3.0f, 3.0f);
        System.Numerics.Vector3 testVector2 = new System.Numerics.Vector3(-4.5f, 2.0f, 1.5f);

        System.Numerics.Vector3 result = HexALOT_DataStructures.VectorHelper.GetAngleBetween(testVector1, testVector2);
        //Debug.Log("Result1: " + result);
        testVector1 = new System.Numerics.Vector3(3.0f, 3.0f, 3.0f);
        testVector2 = new System.Numerics.Vector3(4.5f, 2.0f, 1.5f);

        result = HexALOT_DataStructures.VectorHelper.GetAngleBetween(testVector1, testVector2);
        //Debug.Log("Result2: " + result);
    }
    public float DistanceTo(HexALOT_DataStructures.Point Target)
    {
        float Distance = System.Numerics.Vector3.Distance(JointList[JointList.Count].End.GlobalPos, Target.GlobalPos);
        return Distance;
    }
    public bool Reachable(HexALOT_DataStructures.Point Target, out float Distance, float WithinDistance = 0.01f, int Iterations = 50, List<HexALOT_DataStructures.Joint> Joints = null)
    {
        Joints = Joints == null ? JointList : Joints;
        List<HexALOT_DataStructures.Joint> JointsClone = new List<HexALOT_DataStructures.Joint>(Joints);
        Solve(JointsClone, Target, Iterations);
        Distance = System.Numerics.Vector3.Distance(JointsClone[JointsClone.Count].End.GlobalPos, Target.GlobalPos);
        return Distance < WithinDistance;
    }
    public bool Reachable(HexALOT_DataStructures.Point Target, float WithinDistance = 0.01f, int Iterations = 50)
    {
        return Reachable(Target, out float Distance, WithinDistance, Iterations);
    }
}
