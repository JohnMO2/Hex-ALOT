using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Numerics;

public class test : MonoBehaviour
{
    public Transform SampleJointTF;
    public Transform Target;
    public Transform Base;
    public JMO_KinematicsSolver IKSolver;
    public HexALOT_DataStructures DS;
    public int Count = 3;
    public Transform Hip;
    public Transform Femur;
    public Transform Tibia;
    List<HexALOT_DataStructures.Joint> Joints = new List<HexALOT_DataStructures.Joint>();
    List<Transform> VisualModels = new List<Transform>();
    HexALOT_DataStructures.Point BasePoint = new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 0, 0));
    // Start is called before the first frame update
    void Start()
    {
        Joints.Add(new HexALOT_DataStructures.Joint(new HexALOT_DataStructures.Point(new System.Numerics.Vector3(-0.4225f, -0.01600004f, -0.0044f)), new HexALOT_DataStructures.Point(new System.Numerics.Vector3(-0.8535f, 0, 0))));
        Joints.Add(new HexALOT_DataStructures.Joint(new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 0, 0)), new HexALOT_DataStructures.Point(new System.Numerics.Vector3(-0.744f, 0, 0)), Joints[Joints.Count - 1]));
        Joints.Add(new HexALOT_DataStructures.Joint(new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 0, 0)), new HexALOT_DataStructures.Point(new System.Numerics.Vector3(-1.4983f, -0.2419f, 0)), Joints[Joints.Count - 1]));
        VisualModels.Add(Hip);
        VisualModels.Add(Femur);
        VisualModels.Add(Tibia);
        Joints[0].Start.SetParent(BasePoint);
        Joints[0].Start.LocalRotationLimit.Min = new System.Numerics.Vector3(0, -60, 0) * Mathf.Deg2Rad;
        Joints[0].Start.LocalRotationLimit.Max = new System.Numerics.Vector3(0, 60, 0)  * Mathf.Deg2Rad;
        Joints[0].Start.LocalRotationLimit.UseLimit = true;
        Joints[1].Start.LocalRotationLimit.Min = new System.Numerics.Vector3(0, 0, -90)  * Mathf.Deg2Rad;
        Joints[1].Start.LocalRotationLimit.Max = new System.Numerics.Vector3(0, 0, 90)  * Mathf.Deg2Rad;
        Joints[1].Start.LocalRotationLimit.UseLimit = true;
        Joints[2].Start.LocalRotationLimit.Min = new System.Numerics.Vector3(0, 0, 0)  * Mathf.Deg2Rad;
        Joints[2].Start.LocalRotationLimit.Max = new System.Numerics.Vector3(0, 0, 115)  * Mathf.Deg2Rad;
        Joints[2].Start.LocalRotationLimit.UseLimit = true;
        IKSolver.BuildList(Joints[0], Joints[Joints.Count - 1]);
    }

    // Update is called once per frame
    void Update()
    {
        BasePoint.SetGlobalPos(new System.Numerics.Vector3(Base.position.x, Base.position.y, Base.position.z));
        BasePoint.SetGlobalRot(new System.Numerics.Quaternion(Base.rotation.x, Base.rotation.y, Base.rotation.z, Base.rotation.w));
        if (Count < 1)
        {
            Count = 1;
        }
        if (Count > Joints.Count)
        {
            AddAnotherJoint();
        }
        if (Count < Joints.Count)
        {
            RemoveJoint();

        }
        IKSolver.Solve(new HexALOT_DataStructures.Point(new System.Numerics.Vector3(Target.position.x, Target.position.y, Target.position.z)), 50);
        UpdateJointVisualModels();

    }
    void RemoveJoint()
    {
        if (Joints.Count <= 1)
        {
            return;
        }
        Joints.RemoveAt(Joints.Count - 1);
        Destroy(VisualModels[VisualModels.Count - 1].gameObject);
        VisualModels.RemoveAt(VisualModels.Count - 1);
        IKSolver.BuildList(Joints[0], Joints[Joints.Count - 1]);
    }
    void AddAnotherJoint()
    {

        if (Joints.Count == 0)
        {
            Joints.Add(new HexALOT_DataStructures.Joint(new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 0, 0)), new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 1, 0))));
        }
        else
        {
            Joints.Add(new HexALOT_DataStructures.Joint(new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 0, 0)), new HexALOT_DataStructures.Point(new System.Numerics.Vector3(0, 1, 0)), Joints[Joints.Count - 1]));
        }
        
        VisualModels.Add(Instantiate(SampleJointTF));
        IKSolver.BuildList(Joints[0], Joints[Joints.Count - 1]);
    }
    void UpdateJointVisualModels()
    {
        for (int i = 0; i < VisualModels.Count; i++)
        {
            VisualModels[i].transform.position = new UnityEngine.Vector3(Joints[i].Start.GlobalPos.X, Joints[i].Start.GlobalPos.Y, Joints[i].Start.GlobalPos.Z);
            VisualModels[i].transform.rotation = new UnityEngine.Quaternion(Joints[i].Start.GlobalRot.X, Joints[i].Start.GlobalRot.Y, Joints[i].Start.GlobalRot.Z, Joints[i].Start.GlobalRot.W);
        }
    }

}
